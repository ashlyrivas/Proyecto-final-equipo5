# importar formularios de django
from django import forms
# importar los modelos
from .models import Categoria, Proveedor, Producto

# crear un formulario personalizado
class CategoriaForm(forms.ModelForm):
    
    # personalizar el formulario
    class Meta:
        model = Categoria
        # campos
        fields = ["nombre", "descripcion"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre Categoria"}),
            "descripcion": forms.Textarea(attrs={"class": "form-control", "placeholder": "Descripción Categoria", "rows": 3})
        }
        
        
class ProveedorForm(forms.ModelForm):
    
    class Meta:
        model = Proveedor
        # campos
        fields = ["nombre", "telefono", "email", "direccion", "contacto"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre Proveedor"}),
            "telefono": forms.TextInput(attrs={"class": "form-control", "placeholder": "Numero Telefono", "type": "tel"}),
            "email": forms.TextInput(attrs={"class": "form-control", "placeholder": "Correo Electronico", "type": "email"}),
            "direccion": forms.Textarea(attrs={"class": "form-control", "placeholder": "Dirección Proveedor", "rows": 3}),
            "contacto": forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre Contacto"}),
        }


class ProductoForm(forms.ModelForm):
    """
    Formulario personalizado para el modelo Producto.
    Incluye estilos de Bootstrap para cada campo del formulario.
    """
    class Meta:
        model = Producto
        # campos del formulario
        fields = ["nombre", "descripcion", "precio_compra", "precio_venta", "categoria", "proveedor"]
        widgets = {
            "nombre": forms.TextInput(attrs={
                "class": "form-control", 
                "placeholder": "Nombre del Producto"
            }),
            "descripcion": forms.Textarea(attrs={
                "class": "form-control", 
                "placeholder": "Descripción del Producto", 
                "rows": 3
            }),
            "precio_compra": forms.NumberInput(attrs={
                "class": "form-control", 
                "placeholder": "Precio de Compra",
                "step": "0.01",
                "min": "0"
            }),
            "precio_venta": forms.NumberInput(attrs={
                "class": "form-control", 
                "placeholder": "Precio de Venta",
                "step": "0.01",
                "min": "0"
            }),
            "categoria": forms.Select(attrs={
                "class": "form-select"
            }),
            "proveedor": forms.Select(attrs={
                "class": "form-select"
            }),
        }
        labels = {
            "nombre": "Nombre",
            "descripcion": "Descripción",
            "precio_compra": "Precio de Compra ($)",
            "precio_venta": "Precio de Venta ($)",
            "categoria": "Categoría",
            "proveedor": "Proveedor"
        }