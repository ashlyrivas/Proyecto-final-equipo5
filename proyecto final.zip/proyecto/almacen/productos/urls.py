from django.urls import path
# importando las vistas
from .views import (
    CategoriaListView,
    CategoriaCreateView,
    # proveedores
    ProveedorListView,
    ProveedorCreateView,
    # productos
    ProductoListView,
    ProductoCreateView
)

# agregar un identificador de enrutamiento
app_name = "productos"

# enrutamiento
urlpatterns = [
    # Categorías
    path('categorias/', CategoriaListView.as_view(), name="categoria-list"),
    path('categorias/nueva', CategoriaCreateView.as_view(), name="categoria-create"),
    
    # Proveedores
    path('proveedores/', ProveedorListView.as_view(), name="proveedor-list"),
    path('proveedores/nuevo', ProveedorCreateView.as_view(), name="proveedor-create"),
    
    # Productos
    path('', ProductoListView.as_view(), name="producto-list"),
    path('nuevo', ProductoCreateView.as_view(), name="producto-create"),
]
