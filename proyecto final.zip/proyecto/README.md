# 🏪 Sistema de Gestión de Inventario - Almacén 2025

Sistema web desarrollado en Django para la gestión integral de inventario de productos, incluyendo categorías, proveedores y productos con sus respectivos precios.

---

## 👥 Integrantes del Equipo

| Nombre | Código | Email |
|--------|--------|-------|
| *[Nombre del Integrante 1]* | *[Código]* | *[email@ejemplo.com]* |
| *[Nombre del Integrante 2]* | *[Código]* | *[email@ejemplo.com]* |
| *[Nombre del Integrante 3]* | *[Código]* | *[email@ejemplo.com]* |

> **Nota:** Por favor, completa la información de los integrantes del equipo en la tabla anterior.

---

## 📋 Descripción del Proyecto

Este proyecto es un sistema de gestión de inventario que permite administrar el stock de productos de un almacén o tienda. El sistema está construido con Django Framework y utiliza vistas genéricas basadas en clases (Class-Based Views) para implementar las operaciones CRUD (Crear, Leer, Actualizar, Eliminar).

### Características Principales:

- ✅ **Gestión de Productos**: Permite listar y registrar productos con información detallada
- ✅ **Gestión de Categorías**: Organiza los productos por categorías
- ✅ **Gestión de Proveedores**: Mantiene un registro de los proveedores
- ✅ **Interfaz Moderna**: Diseño responsivo con Bootstrap 5 y tema oscuro
- ✅ **Cálculo Automático de Márgenes**: Visualiza el margen de ganancia de cada producto

### Funcionalidades Implementadas:

#### 🔹 Productos
- **ListView**: Muestra todos los productos del inventario en una tabla interactiva
- **CreateView**: Formulario para registrar nuevos productos con validación

#### 🔹 Categorías
- **ListView**: Listado completo de categorías disponibles
- **CreateView**: Registro de nuevas categorías para clasificar productos

#### 🔹 Proveedores
- **ListView**: Visualización de todos los proveedores registrados
- **CreateView**: Formulario para agregar nuevos proveedores con datos de contacto

---

## 🛣️ Rutas Implementadas

### Productos

| Método | Ruta | Nombre | Descripción |
|--------|------|--------|-------------|
| GET | `/productos/` | `producto-list` | Muestra el listado completo de todos los productos registrados en el inventario. Incluye información de precios, categoría, proveedor y margen de ganancia. |
| GET/POST | `/productos/nuevo` | `producto-create` | Formulario para registrar un nuevo producto. Permite ingresar nombre, descripción, precios (compra y venta), categoría y proveedor. |

### Categorías

| Método | Ruta | Nombre | Descripción |
|--------|------|--------|-------------|
| GET | `/productos/categorias/` | `categoria-list` | Lista todas las categorías disponibles para clasificar los productos. |
| GET/POST | `/productos/categorias/nueva` | `categoria-create` | Formulario para crear una nueva categoría con nombre y descripción. |

### Proveedores

| Método | Ruta | Nombre | Descripción |
|--------|------|--------|-------------|
| GET | `/productos/proveedores/` | `proveedor-list` | Muestra el listado de todos los proveedores registrados. |
| GET/POST | `/productos/proveedores/nuevo` | `proveedor-create` | Formulario para registrar un nuevo proveedor con datos de contacto (nombre, teléfono, email, dirección y persona de contacto). |

### Administración

| Método | Ruta | Nombre | Descripción |
|--------|------|--------|-------------|
| GET/POST | `/admin/` | `admin` | Panel de administración de Django para gestión avanzada del sistema. |

---

## 🚀 Funcionamiento del Proyecto

### Arquitectura

El proyecto sigue el patrón de diseño **MVT (Model-View-Template)** de Django:

1. **Modelos (Models)**: Definen la estructura de la base de datos
   - `Producto`: Almacena información de productos (nombre, descripción, precios, categoría, proveedor)
   - `Categoria`: Organiza los productos por tipo
   - `Proveedor`: Mantiene información de contacto de proveedores

2. **Vistas (Views)**: Lógica de negocio usando Class-Based Views
   - `ListView`: Para mostrar listados de registros
   - `CreateView`: Para crear nuevos registros con formularios

3. **Plantillas (Templates)**: Interfaz de usuario con Bootstrap 5
   - Tema oscuro para mejor experiencia visual
   - Diseño responsivo que se adapta a dispositivos móviles
   - Formularios con validación en el cliente

### Flujo de Trabajo Típico

1. **Preparación Inicial**:
   - El administrador crea categorías (Ej: Electrónica, Alimentos, Ropa)
   - Se registran los proveedores con sus datos de contacto

2. **Registro de Productos**:
   - Se accede al formulario de nuevo producto
   - Se completan los campos requeridos (nombre, precios, categoría, proveedor)
   - El sistema valida la información y guarda el producto

3. **Visualización del Inventario**:
   - La lista de productos muestra toda la información relevante
   - Se calculan automáticamente los márgenes de ganancia
   - Los productos se pueden filtrar y buscar fácilmente

### Tecnologías Utilizadas

- **Backend**: Django 5.2 (Framework de Python)
- **Frontend**: Bootstrap 5 (Framework CSS)
- **Base de Datos**: SQLite (por defecto, puede cambiarse a PostgreSQL/MySQL)
- **Lenguaje de Programación**: Python 3.x

---

## 💻 Instalación y Configuración

### Requisitos Previos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- Virtualenv (recomendado)

### Pasos de Instalación

1. **Clonar el repositorio**:
```bash
git clone <url-del-repositorio>
cd Almacen-2025-G2-main/almacen
```

2. **Crear y activar un entorno virtual**:
```bash
# En Windows
python -m venv venv
venv\Scripts\activate

# En Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

3. **Instalar las dependencias**:
```bash
pip install -r requirements.txt
```

4. **Realizar las migraciones de la base de datos**:
```bash
python manage.py makemigrations
python manage.py migrate
```

5. **Crear un superusuario (administrador)**:
```bash
python manage.py createsuperuser
```

6. **Ejecutar el servidor de desarrollo**:
```bash
python manage.py runserver
```

7. **Acceder a la aplicación**:
   - Abre tu navegador y visita: `http://127.0.0.1:8000/productos/`
   - Panel de administración: `http://127.0.0.1:8000/admin/`

---

## 📱 Uso de la Aplicación

### Registro de Categorías y Proveedores

Antes de registrar productos, es necesario tener al menos:
- Una categoría creada
- Un proveedor registrado

Puedes crear estos registros desde:
- El panel de administración (`/admin/`)
- Los formularios web (`/productos/categorias/nueva` y `/productos/proveedores/nuevo`)

### Registro de Productos

1. Accede a `/productos/nuevo`
2. Completa el formulario con la información del producto:
   - **Nombre**: Nombre descriptivo del producto
   - **Descripción**: Detalles adicionales (opcional)
   - **Precio de Compra**: Costo al que se adquiere el producto
   - **Precio de Venta**: Precio al que se vende al cliente
   - **Categoría**: Selecciona de la lista desplegable
   - **Proveedor**: Selecciona de la lista desplegable
3. Haz clic en "Guardar Producto"

### Visualización del Inventario

- Accede a `/productos/` para ver todos los productos
- La tabla muestra información detallada incluyendo:
  - Nombre y descripción
  - Precios de compra y venta
  - Categoría y proveedor asociados
  - Margen de ganancia calculado automáticamente

---

## 🎨 Características de la Interfaz

- **Tema Oscuro**: Diseño moderno con colores oscuros que reduce la fatiga visual
- **Responsivo**: Se adapta a diferentes tamaños de pantalla (móvil, tablet, escritorio)
- **Navegación Intuitiva**: Menú claro con acceso rápido a todas las secciones
- **Tablas Interactivas**: Visualización organizada de la información
- **Formularios Validados**: Campos con validación y mensajes de error claros
- **Iconos Bootstrap**: Interfaz visual más atractiva y comprensible

---

## 📂 Estructura del Proyecto

```
almacen/
├── almacen/                 # Configuración principal del proyecto
│   ├── settings.py         # Configuración de Django
│   ├── urls.py             # Rutas principales
│   └── wsgi.py             # Configuración WSGI
├── core/                    # Aplicación principal
│   └── templates/
│       └── core/
│           └── base.html    # Plantilla base con navbar
├── productos/               # Aplicación de productos
│   ├── models.py           # Modelos de datos
│   ├── views.py            # Vistas genéricas (CBV)
│   ├── forms.py            # Formularios personalizados
│   ├── urls.py             # Rutas de la app
│   ├── admin.py            # Configuración del admin
│   └── templates/
│       ├── productos/      # Plantillas de productos
│       ├── categorias/     # Plantillas de categorías
│       └── proveedores/    # Plantillas de proveedores
├── static/                  # Archivos estáticos (CSS, JS)
├── manage.py               # Script de gestión de Django
└── requirements.txt        # Dependencias del proyecto
```

---

## 🔧 Configuración Adicional

### Base de Datos

El proyecto usa SQLite por defecto. Para usar PostgreSQL o MySQL, modifica la configuración en `settings.py`:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'nombre_db',
        'USER': 'usuario',
        'PASSWORD': 'contraseña',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

### Archivos Estáticos

Para producción, ejecuta:
```bash
python manage.py collectstatic
```

---

## 🐛 Solución de Problemas

### Error: "no such table: productos_producto"
**Solución**: Ejecuta las migraciones:
```bash
python manage.py makemigrations
python manage.py migrate
```

### Error: "No module named 'django'"
**Solución**: Asegúrate de tener el entorno virtual activado e instala las dependencias:
```bash
pip install -r requirements.txt
```

### Error: Categoría o Proveedor no aparece en el formulario
**Solución**: Crea al menos una categoría y un proveedor antes de registrar productos.

---

## 📝 Notas Importantes

- ⚠️ Este proyecto está configurado para desarrollo. Para producción, configura `DEBUG = False` y ajusta `ALLOWED_HOSTS` en `settings.py`.
- 🔐 Cambia la `SECRET_KEY` en producción.
- 💾 Realiza respaldos regulares de la base de datos.
- 🔄 Mantén las dependencias actualizadas por seguridad.

---

## 📄 Licencia

Este proyecto es de uso académico para el curso de Desarrollo Web.

---

## 🤝 Contribuciones

Este proyecto fue desarrollado como parte del curso académico. Las contribuciones están abiertas para mejoras y nuevas funcionalidades.

---

## 📞 Contacto

Para preguntas o soporte sobre el proyecto, contacta a los integrantes del equipo (ver sección de Integrantes).

---

**Desarrollado con ❤️ usando Django Framework** | Almacén 2025 - Grupo G2
