# CRUD en Django - Clínica (Pacientes, Médicos y Citas)
## Pasos rápidos
1. Crea y activa un entorno virtual.
2. `pip install -r requirements.txt`
3. `python manage.py migrate`
4. (Opcional) `python manage.py createsuperuser`
5. `python manage.py runserver`
6. Abre http://127.0.0.1:8000/ y prueba.
