from django.db import models
class Paciente(models.Model):
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100)
    fecha_nacimiento = models.DateField(null=True, blank=True)
    dui = models.CharField('DUI', max_length=10, unique=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=255, blank=True)
    def __str__(self):
        return f"{self.nombres} {self.apellidos}"
class Medico(models.Model):
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100, blank=True)
    especialidad = models.CharField(max_length=120)
    telefono = models.CharField(max_length=15, blank=True)
    email = models.EmailField(blank=True)
    def __str__(self):
        return f"Dr(a). {self.nombres} {self.apellidos} - {self.especialidad}"
class Cita(models.Model):
    ESTADOS = [('pendiente','Pendiente'),('confirmada','Confirmada'),('atendida','Atendida'),('cancelada','Cancelada')]
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, related_name='citas')
    medico = models.ForeignKey(Medico, on_delete=models.PROTECT, related_name='citas')
    fecha = models.DateField()
    hora = models.TimeField()
    motivo = models.CharField(max_length=200, blank=True)
    estado = models.CharField(max_length=10, choices=ESTADOS, default='pendiente')
    class Meta:
        unique_together = ('medico','fecha','hora')
    def __str__(self):
        return f"{self.fecha} {self.hora} - {self.paciente} con {self.medico}"
