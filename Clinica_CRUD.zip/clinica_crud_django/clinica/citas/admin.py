from django.contrib import admin
from .models import Paciente, Medico, Cita
@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ('nombres','apellidos','dui','telefono')
    search_fields = ('nombres','apellidos','dui')
@admin.register(Medico)
class MedicoAdmin(admin.ModelAdmin):
    list_display = ('nombres','apellidos','especialidad','telefono')
    search_fields = ('nombres','apellidos','especialidad')
@admin.register(Cita)
class CitaAdmin(admin.ModelAdmin):
    list_display = ('fecha','hora','paciente','medico','estado')
    list_filter = ('estado','fecha','medico')
    search_fields = ('paciente__nombres','paciente__apellidos','motivo')
