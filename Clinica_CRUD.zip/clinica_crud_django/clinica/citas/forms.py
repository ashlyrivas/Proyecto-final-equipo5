from django import forms
from .models import Paciente, Medico, Cita
class DateInput(forms.DateInput): input_type='date'
class TimeInput(forms.TimeInput): input_type='time'
class PacienteForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = ['nombres','apellidos','fecha_nacimiento','dui','telefono','direccion']
        widgets = {'fecha_nacimiento': DateInput()}
class MedicoForm(forms.ModelForm):
    class Meta:
        model = Medico
        fields = ['nombres','apellidos','especialidad','telefono','email']
class CitaForm(forms.ModelForm):
    class Meta:
        model = Cita
        fields = ['paciente','medico','fecha','hora','motivo','estado']
        widgets = {'fecha': DateInput(), 'hora': TimeInput()}
