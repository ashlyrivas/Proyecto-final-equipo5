from django.db import models

class Cita(models.Model):
    paciente = models.CharField(max_length=100)
    medico = models.CharField(max_length=100)
    fecha = models.DateField()
    hora = models.TimeField()

    def __str__(self):
        return f"{self.paciente} - {self.fecha} {self.hora}"
