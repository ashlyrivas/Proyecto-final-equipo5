from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import Paciente, Medico, Cita
from .forms import PacienteForm, MedicoForm, CitaForm
class CitaList(ListView):
    model = Cita
    template_name = 'citas/list.html'
    context_object_name = 'items'
    ordering = ['-fecha','-hora']
class CitaCreate(CreateView):
    model = Cita; form_class = CitaForm
    template_name = 'citas/form.html'; success_url = reverse_lazy('cita_list')
class CitaUpdate(UpdateView):
    model = Cita; form_class = CitaForm
    template_name = 'citas/form.html'; success_url = reverse_lazy('cita_list')
class CitaDelete(DeleteView):
    model = Cita; template_name = 'citas/confirm_delete.html'; success_url = reverse_lazy('cita_list')
class PacienteList(ListView):
    model = Paciente; template_name = 'pacientes/list.html'; context_object_name = 'items'; ordering = ['nombres']
class PacienteCreate(CreateView):
    model = Paciente; form_class = PacienteForm
    template_name = 'pacientes/form.html'; success_url = reverse_lazy('paciente_list')
class PacienteUpdate(UpdateView):
    model = Paciente; form_class = PacienteForm
    template_name = 'pacientes/form.html'; success_url = reverse_lazy('paciente_list')
class PacienteDelete(DeleteView):
    model = Paciente; template_name = 'pacientes/confirm_delete.html'; success_url = reverse_lazy('paciente_list')
class MedicoList(ListView):
    model = Medico; template_name = 'medicos/list.html'; context_object_name = 'items'; ordering = ['nombres']
class MedicoCreate(CreateView):
    model = Medico; form_class = MedicoForm
    template_name = 'medicos/form.html'; success_url = reverse_lazy('medico_list')
class MedicoUpdate(UpdateView):
    model = Medico; form_class = MedicoForm
    template_name = 'medicos/form.html'; success_url = reverse_lazy('medico_list')
class MedicoDelete(DeleteView):
    model = Medico; template_name = 'medicos/confirm_delete.html'; success_url = reverse_lazy('medico_list')
