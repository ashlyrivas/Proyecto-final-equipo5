from django.urls import path
from . import views
urlpatterns = [
    path('', views.CitaList.as_view(), name='cita_list'),
    path('citas/', views.CitaList.as_view(), name='cita_list'),
    path('citas/nueva/', views.CitaCreate.as_view(), name='cita_create'),
    path('citas/<int:pk>/editar/', views.CitaUpdate.as_view(), name='cita_update'),
    path('citas/<int:pk>/eliminar/', views.CitaDelete.as_view(), name='cita_delete'),
    path('pacientes/', views.PacienteList.as_view(), name='paciente_list'),
    path('pacientes/nuevo/', views.PacienteCreate.as_view(), name='paciente_create'),
    path('pacientes/<int:pk>/editar/', views.PacienteUpdate.as_view(), name='paciente_update'),
    path('pacientes/<int:pk>/eliminar/', views.PacienteDelete.as_view(), name='paciente_delete'),
    path('medicos/', views.MedicoList.as_view(), name='medico_list'),
    path('medicos/nuevo/', views.MedicoCreate.as_view(), name='medico_create'),
    path('medicos/<int:pk>/editar/', views.MedicoUpdate.as_view(), name='medico_update'),
    path('medicos/<int:pk>/eliminar/', views.MedicoDelete.as_view(), name='medico_delete'),
]
